#ifdef OS_ABL_SUPPORT

#include <linux/module.h>
#include "rt_config.h"

EXPORT_SYMBOL(RTMP_DRV_OPS_FUNCTION);

#endif /* OS_ABL_SUPPORT */

